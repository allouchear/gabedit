
#ifndef __GABEDIT_NMRSPECTRUM_H__
#define __GABEDIT_NMRSPECTRUM_H__

void createNMRSpectrum(GtkWidget *parentWindow, GabEditTypeFile typeOfFile);

#endif /* __GABEDIT_NMRSPECTRUM_H__ */
