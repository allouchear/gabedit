
#ifndef __GABEDIT_MOPACGLOBAL_H__
#define __GABEDIT_MOPACGLOBAL_H__

GtkWidget* mopacWin;
MopacMolecule mopacMolecule;
MopacColorFore mopacColorFore;
MopacColorBack mopacColorBack;

MopacFunctional* functionals;
MopacStdFunctional* stdFunctionals;
gfloat* sumFunctionals;

#endif /* __GABEDIT_MOPACGLOBAL_H__ */

