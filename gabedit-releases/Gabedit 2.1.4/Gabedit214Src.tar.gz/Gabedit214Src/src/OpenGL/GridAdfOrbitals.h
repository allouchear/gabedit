
#ifndef __GABEDIT_GRIDADFORBITALS_H__
#define __GABEDIT_GRIDADFORBITALS_H__

void load_adf_file_orbitals(GabeditFileChooser *SelecFile, gint response_id);

#endif /* __GABEDIT_GRIDADFORBITALS_H__ */

