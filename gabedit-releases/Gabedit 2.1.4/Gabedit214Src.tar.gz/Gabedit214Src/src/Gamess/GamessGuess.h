#ifndef __GABEDIT_GAMESSGUESS_H__
#define __GABEDIT_GAMESSGUESS_H__

void initGamessGuessFrame();
void setSensitiveGamessGuessFrame(gboolean sensitive);
void putGamessGuessInfoInTextEditor();
void createGamessGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_GAMESSGUESS_H__ */
