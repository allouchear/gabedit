#ifndef __GABEDIT_FIREFLYGUESS_H__
#define __GABEDIT_FIREFLYGUESS_H__

void initFireFlyGuessFrame();
void setSensitiveFireFlyGuessFrame(gboolean sensitive);
void putFireFlyGuessInfoInTextEditor();
void createFireFlyGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_FIREFLYGUESS_H__ */
