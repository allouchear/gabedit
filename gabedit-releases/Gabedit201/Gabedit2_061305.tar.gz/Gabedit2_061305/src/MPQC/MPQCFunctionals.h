
#ifndef __GABEDIT_MPQCFUNCTIONALS_H__
#define __GABEDIT_MPQCFUNCTIONALS_H__

void initMPQCFunctionals();
void freeMPQCFunctionals();
void initMPQCStdFunctionals();
void freeMPQCStdFunctionals();
void mpqcSumDensityFunctionalWindow();

#endif /* __GABEDIT_MPQCFUNCTIONALS_H__ */

