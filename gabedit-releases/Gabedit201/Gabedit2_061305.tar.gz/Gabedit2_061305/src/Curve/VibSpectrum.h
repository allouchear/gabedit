
#ifndef __GABEDIT_VIBSPECTRUM_H__
#define __GABEDIT_VIBSPECTRUM_H__

void createVibrationSpectrum(GtkWidget *parentWindow, Vibration vibration);

#endif /* __GABEDIT_VIBSPECTRUM_H__ */
