
#ifndef __GABEDIT_LOADPDBTEMPLATE_H__
#define __GABEDIT_LOADPDBTEMPLATE_H__

gboolean readPDBTemplate(PDBTemplate* pdbTemplate,gchar* filename);

#endif /* __GABEDIT_LOADPDBTEMPLATE_H__ */

