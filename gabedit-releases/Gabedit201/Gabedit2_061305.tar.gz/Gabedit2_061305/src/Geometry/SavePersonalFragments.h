
#ifndef __GABEDIT_SAVEPERSONALFRAGMENTS_H__
#define __GABEDIT_SAVEPERSONALFRAGMENTS_H__

gboolean saveAllPersonalFragments(PersonalFragments* personnalFragments,gchar* filename);

#endif /* __GABEDIT_SAVEPERSONALFRAGMENTS_H__ */

