
#ifndef __GABEDIT_POVRAY_H__
#define __GABEDIT_POVRAY_H__

void create_save_povray(GtkWidget* Win);

#endif /* __GABEDIT_POVRAY_H__ */

