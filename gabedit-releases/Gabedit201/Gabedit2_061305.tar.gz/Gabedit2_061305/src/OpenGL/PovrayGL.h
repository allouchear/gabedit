
#ifndef __GABEDIT_POVRAYGL_H__
#define __GABEDIT_POVRAYGL_H__

gchar* new_pov(gchar* dirname, int i);
void create_save_povray_orb(GtkWidget* Win);

#endif /* __GABEDIT_POVRAYGL_H__ */

