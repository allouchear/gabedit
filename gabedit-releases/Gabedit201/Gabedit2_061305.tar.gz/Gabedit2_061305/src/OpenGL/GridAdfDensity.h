
#ifndef __GABEDIT_GRIDADFDENSITY_H__
#define __GABEDIT_GRIDADFDENSITY_H__

void load_adf_file_density(GabeditFileChooser *SelecFile, gint response_id);

#endif /* __GABEDIT_GRIDADFDENSITY_H__ */
