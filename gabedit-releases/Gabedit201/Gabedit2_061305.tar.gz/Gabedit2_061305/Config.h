/* Config header file */
#define GTK_DISABLE_DEPRECATED
