#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/Users/manip/local/lib"
XML2_LIBS="-lxml2 -lz -lpthread  -liconv -lm "
XML2_INCLUDEDIR="-I/Users/manip/local/include/libxml2"
MODULE_VERSION="xml2-2.6.23"

