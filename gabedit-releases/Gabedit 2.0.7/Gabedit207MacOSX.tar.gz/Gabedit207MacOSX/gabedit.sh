#! /bin/sh
#export  GABEDITDIR=$HOME/GabeditMacOSX
export  GABEDITDIR=`dirname $0`
cd $GABEDITDIR
#export  DYLD_LIBRARY_PATH=./lib:$DYLD_LIBRARY_PATH
export  DYLD_LIBRARY_PATH=./lib
export  LIBRARY_PATH=./lib:$LIBRARY_PATH
export  PANGO_RC_FILE=./pango/pangorc
export  GDK_PIXBUF_MODULEDIR=./gdk/loaders
export  GDK_PIXBUF_MODULE_FILE=./gdk/gdk-pixbuf.loaders
export  FONTCONFIG_PATH=./etc/fonts
./.gabedit.exe

