
#ifndef __GABEDIT_CREATEPERSONALMMFILE_H__
#define __GABEDIT_CREATEPERSONALMMFILE_H__

void createPersonalParametersFile(AmberParameters* amberParameters);

#endif /* __GABEDIT_CREATEPERSONALMMFILE_H__ */

