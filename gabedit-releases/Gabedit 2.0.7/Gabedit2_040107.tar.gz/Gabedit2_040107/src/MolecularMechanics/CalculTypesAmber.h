
#ifndef __GABEDIT_CALCULTYPESAMBER_H__
#define __GABEDIT_CALCULTYPESAMBER_H__

void calculTypesAmber(GeomDef* geom, gint nAtoms);

#endif /* __GABEDIT_CALCULTYPESAMBER_H__ */

