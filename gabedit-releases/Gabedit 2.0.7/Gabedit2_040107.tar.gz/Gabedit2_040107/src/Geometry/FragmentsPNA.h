
#ifndef __GABEDIT_FRAGMENTSPNA_H__
#define __GABEDIT_FRAGMENTSPNA_H__

Fragment GetFragmentPNA(gchar* Name);

#endif /* __GABEDIT_FRAGMENTSPNA_H__ */

