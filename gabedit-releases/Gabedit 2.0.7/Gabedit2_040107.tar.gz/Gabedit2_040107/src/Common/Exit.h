#ifndef __GABEDIT_EXIT_H__
#define __GABEDIT_EXIT_H__

void ExitDlg(GtkWidget* w, gpointer data);

#endif /* __GABEDIT_EXIT_H__ */
