/**********************************************************************************************************
Copyright (c) 2002-2007 Abdul-Rahman Allouche. All rights reserved

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the Gabedit), to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or substantial portions
  of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
************************************************************************************************************/

#ifndef __GABEDIT_GABEDITTYPE_H__
#define __GABEDIT_GABEDITTYPE_H__

typedef void (*GabeditSignalFunc)(GtkWidget*);
typedef enum
{
  GABEDIT_NETWORK_FTP_RSH = 0,
  GABEDIT_NETWORK_SSH
} GabEditNetWork;

typedef struct _SAtomsProp
{
	gchar *name;
	gchar *symbol;
	guint atomicNumber;
	gdouble covalentRadii;
	gdouble bondOrderRadii;
	gdouble vanDerWaalsRadii;
	gdouble radii;
	guint maximumBondValence;
	gdouble masse;
	gdouble electronegativity;
	GdkColor color;
}SAtomsProp;
typedef enum
{
  GABEDIT_TYPEWIN_GEOM,
  GABEDIT_TYPEWIN_ORB
} GabEditTypeWin;
typedef enum
{
  GABEDIT_TYPETEXTURE_1,
  GABEDIT_TYPETEXTURE_2,
  GABEDIT_TYPETEXTURE_3,
  GABEDIT_TYPETEXTURE_NONE
} GabEditTypeTexture;
typedef enum
{
  GABEDIT_TYPENODE_GAMESS,
  GABEDIT_TYPENODE_GAUSSIAN,
  GABEDIT_TYPENODE_MOLCAS,
  GABEDIT_TYPENODE_MOLPRO,
  GABEDIT_TYPENODE_MPQC,
  GABEDIT_TYPENODE_XYZ,
  GABEDIT_TYPENODE_MOL2,
  GABEDIT_TYPENODE_TINKER,
  GABEDIT_TYPENODE_PDB,
  GABEDIT_TYPENODE_GZMAT,
  GABEDIT_TYPENODE_MZMAT,
  GABEDIT_TYPENODE_HIN,
  GABEDIT_TYPENODE_OTHER,
} GabEditTypeNode;
typedef enum
{
  GABEDIT_TYPEFILE_GAUSSIAN,
  GABEDIT_TYPEFILE_MOLCAS,
  GABEDIT_TYPEFILE_MOLPRO,
  GABEDIT_TYPEFILE_DALTON,
  GABEDIT_TYPEFILE_GAMESS,
  GABEDIT_TYPEFILE_MOLPRO_LOG,
  GABEDIT_TYPEFILE_MOLDEN,
  GABEDIT_TYPEFILE_GABEDIT,
  GABEDIT_TYPEFILE_XYZ,
  GABEDIT_TYPEFILE_MOL2,
  GABEDIT_TYPEFILE_TINKER,
  GABEDIT_TYPEFILE_PDB,
  GABEDIT_TYPEFILE_GZMAT,
  GABEDIT_TYPEFILE_MZMAT,
  GABEDIT_TYPEFILE_HIN,
  GABEDIT_TYPEFILE_GAMESSINPUT,
  GABEDIT_TYPEFILE_GAUSIANINPUT,
  GABEDIT_TYPEFILE_MOLCASINPUT,
  GABEDIT_TYPEFILE_MOLPROINPUT,
  GABEDIT_TYPEFILE_MPQCINPUT,
  GABEDIT_TYPEFILE_MPQC,
  GABEDIT_TYPEFILE_JPEG,
  GABEDIT_TYPEFILE_PPM,
  GABEDIT_TYPEFILE_BMP,
  GABEDIT_TYPEFILE_PNG,
  GABEDIT_TYPEFILE_PS,
  GABEDIT_TYPEFILE_CUBEGAUSS,
  GABEDIT_TYPEFILE_CUBEMOLPRO,
  GABEDIT_TYPEFILE_CUBEADF,
  GABEDIT_TYPEFILE_CUBEM2MSI,
  GABEDIT_TYPEFILE_CUBEMOLCAS,
  GABEDIT_TYPEFILE_CUBEGABEDIT,
  GABEDIT_TYPEFILE_UNKNOWN,
} GabEditTypeFile;

typedef enum
{
  GABEDIT_TYPEFILEGEOM_NEW,

  GABEDIT_TYPEFILEGEOM_GABEDIT,
  GABEDIT_TYPEFILEGEOM_MOLDEN,

  GABEDIT_TYPEFILEGEOM_XYZ,
  GABEDIT_TYPEFILEGEOM_MOL2,
  GABEDIT_TYPEFILEGEOM_TINKER,
  GABEDIT_TYPEFILEGEOM_PDB,
  GABEDIT_TYPEFILEGEOM_HIN,

  GABEDIT_TYPEFILEGEOM_DALTONIN,
  GABEDIT_TYPEFILEGEOM_DALTONFIRST,
  GABEDIT_TYPEFILEGEOM_DALTONLAST,

  GABEDIT_TYPEFILEGEOM_GAMESSIN,
  GABEDIT_TYPEFILEGEOM_GAMESSFIRST,
  GABEDIT_TYPEFILEGEOM_GAMESSLAST,

  GABEDIT_TYPEFILEGEOM_GAUSSIN,
  GABEDIT_TYPEFILEGEOM_GAUSSOUTFIRST,
  GABEDIT_TYPEFILEGEOM_GAUSSOUTLAST,

  GABEDIT_TYPEFILEGEOM_MOLCASIN,
  GABEDIT_TYPEFILEGEOM_MOLCASOUTFIRST,
  GABEDIT_TYPEFILEGEOM_MOLCASOUTLAST,

  GABEDIT_TYPEFILEGEOM_MOLPROIN,
  GABEDIT_TYPEFILEGEOM_MOLPROOUTFIRST,
  GABEDIT_TYPEFILEGEOM_MOLPROOUTLAST,

  GABEDIT_TYPEFILEGEOM_MPQCIN,
  GABEDIT_TYPEFILEGEOM_MPQCOUTFIRST,
  GABEDIT_TYPEFILEGEOM_MPQCOUTLAST,

  GABEDIT_TYPEFILEGEOM_GAUSSIAN_ZMATRIX,
  GABEDIT_TYPEFILEGEOM_MOPAC_ZMATRIX,

  GABEDIT_TYPEFILEGEOM_UNKNOWN
} GabEditTypeFileGeom;

typedef enum
{
  GABEDIT_TYPEGRID_ORBITAL,
  GABEDIT_TYPEGRID_EDENSITY,
  GABEDIT_TYPEGRID_DDENSITY,
  GABEDIT_TYPEGRID_ADENSITY,
  GABEDIT_TYPEGRID_SDENSITY,
  GABEDIT_TYPEGRID_ELFBECKE,
  GABEDIT_TYPEGRID_ELFSAVIN,
} GabEditTypeGrid;

typedef enum
{
  GABEDIT_TYPEGEOM_NO,
  GABEDIT_TYPEGEOM_BALLSTICK,
  GABEDIT_TYPEGEOM_STICK,
  GABEDIT_TYPEGEOM_SPACE,
  GABEDIT_TYPEGEOM_WIREFRAME
} GabEditTypeGeom;

typedef enum
{
  GABEDIT_SURFSHOW_NO,
  GABEDIT_SURFSHOW_POSNEG,
  GABEDIT_SURFSHOW_POSITIVE,
  GABEDIT_SURFSHOW_NEGATIVE
} GabEditTypeSurfShow;

typedef enum
{
  GABEDIT_BLEND_NO,
  GABEDIT_BLEND_YES
} GabEditTypeBlend;

typedef enum
{
  GABEDIT_POS_WIREFRAME_NO,
  GABEDIT_POS_WIREFRAME_YES,
  GABEDIT_NEG_WIREFRAME_NO,
  GABEDIT_NEG_WIREFRAME_YES
} GabEditTypeWireFrame;

typedef struct _LXYZ
{
 gfloat Coef;
 gint l[3];
}LXYZ;

typedef struct _Slm
{
 gint l;
 gint m;
 gint N;
 LXYZ *lxyz;
}Slm;

typedef struct _GTF
{
 gfloat Ex;
 gfloat Coef;
 gint l[3];
 gfloat C[3]; 
}GTF;

typedef struct _AO
{
 gint L;
 gint N;
 gfloat* Ex;
 gfloat* Coef;
 }AO;

typedef struct _TYPE
{
 char* Symb;
 gint N; /* Number of electrons*/
 gint Norb;
 AO *Ao;
 }TYPE;

typedef struct _CGTF
{
 gint N;
 gint NumCenter;
 GTF* Gtf;
 gint L; /* used if spherical basis*/
 gint M; /* used if spherical basis*/
 }CGTF;
typedef struct _RGBColor
{
  guchar rgb[3];

}RGBColor;

typedef struct _TypeGeomOrb
{
	gchar* Symb;
	gfloat C[3];
	SAtomsProp Prop;
	guint Sphere;
	gint N;
	gint NumType;
	gint NAOrb;
	gint* NumOrb;
	gint NOrb;
	gint NAlphaOrb;
	gint NBetaOrb;
	gfloat **CoefAlphaOrbitals;
	gfloat *OccAlphaOrbitals;
	gfloat *EnerAlphaOrbitals;
	gchar	**SymAlphaOrbitals;
	gfloat **CoefBetaOrbitals;
	gfloat *EnerBetaOrbitals;
	gfloat *OccBetaOrbitals;
	gchar	**SymBetaOrbitals;
}TypeGeomOrb;

typedef struct _TypeFontsStyle
{
 gchar *fontname;
 GdkColor BaseColor;
 GdkColor TextColor;
}TypeFontsStyle;
typedef gdouble	 (*Func3d)(gfloat ,gfloat,gfloat,gint);

#endif /* __GABEDIT_GABEDITTYPE_H__ */

