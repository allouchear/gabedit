
#ifndef __GABEDIT_FOLDERCHOOSER_H__
#define __GABEDIT_FOLDERCHOOSER_H__

GtkWidget* selctionOfDir(gpointer data, gchar* title, GabEditTypeWin typewin) ;

#endif /* __GABEDIT_FOLDERCHOOSER_H__ */
