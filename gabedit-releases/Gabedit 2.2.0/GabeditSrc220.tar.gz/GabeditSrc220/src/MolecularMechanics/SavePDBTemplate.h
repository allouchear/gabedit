
#ifndef __GABEDIT_SAVEPDBTEMPLATE_H__
#define __GABEDIT_SAVEPDBTEMPLATE_H__

gboolean savePDBTemplate(PDBTemplate* pdbTemplate,gchar* filename);

#endif /* __GABEDIT_SAVEPDBTEMPLATE_H__ */

