
#ifndef __GABEDIT_MPQCOPTIMISATION_H__
#define __GABEDIT_MPQCOPTIMISATION_H__

void initMPQCOptimisation();
void freeMPQCOptimisation();
void createMPQCOptimisation(GtkWidget *box);
void putMPQCOptimisationInfoInTextEditor();

#endif /* __GABEDIT_MPQCOPTIMISATION_H__ */

