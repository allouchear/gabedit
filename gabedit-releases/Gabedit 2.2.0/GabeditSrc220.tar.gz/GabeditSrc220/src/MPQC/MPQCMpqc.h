
#ifndef __GABEDIT_MPQCMPQC_H__
#define __GABEDIT_MPQCMPQC_H__

void initMPQCMpqc();
void freeMPQCMpqc();
void putMPQCMpqcInfoInTextEditor();

#endif /* __GABEDIT_MPQCMPQC_H__ */

