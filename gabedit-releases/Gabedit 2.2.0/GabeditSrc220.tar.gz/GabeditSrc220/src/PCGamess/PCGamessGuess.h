#ifndef __GABEDIT_PCGAMESSGUESS_H__
#define __GABEDIT_PCGAMESSGUESS_H__

void initPCGamessGuessFrame();
void setSensitivePCGamessGuessFrame(gboolean sensitive);
void putPCGamessGuessInfoInTextEditor();
void createPCGamessGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_PCGAMESSGUESS_H__ */
