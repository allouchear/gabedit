
#ifndef __GABEDIT_MENUTOOLBAR_H__
#define __GABEDIT_MENUTOOLBAR_H__

void add_menu_toolbar();
void window_add(gchar *str,GtkWidget* Win);
void window_delete(GtkWidget* Win);

#endif /* __GABEDIT_MENUTOOLBAR_H__ */

