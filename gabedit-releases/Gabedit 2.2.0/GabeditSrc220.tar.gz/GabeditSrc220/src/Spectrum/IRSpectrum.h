
#ifndef __GABEDIT_IRSPECTRUM_H__
#define __GABEDIT_IRSPECTRUM_H__

void createIRSpectrum(GtkWidget *parentWindow, GabEditTypeFile typeOfFile);
void createIRSpectrumFromVibration(GtkWidget *parentWindow, Vibration ibration);

#endif /* __GABEDIT_IRSPECTRUM_H__ */
