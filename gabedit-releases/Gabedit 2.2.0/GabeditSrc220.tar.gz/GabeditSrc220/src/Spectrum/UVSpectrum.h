
#ifndef __GABEDIT_UVSPECTRUM_H__
#define __GABEDIT_UVSPECTRUM_H__

void createUVSpectrum(GtkWidget *parentWindow, GabEditTypeFile typeOfFile);

#endif /* __GABEDIT_UVSPECTRUM_H__ */
