
#ifndef __GABEDIT_POVRAY_H__
#define __GABEDIT_POVRAY_H__

void export_to_povray(gchar* fileName);

#endif /* __GABEDIT_POVRAY_H__ */

