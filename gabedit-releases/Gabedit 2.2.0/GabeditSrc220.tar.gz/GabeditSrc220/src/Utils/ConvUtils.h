
#ifndef __GABEDIT_CONVUTILS_H__
#define __GABEDIT_CONVUTILS_H__

void create_conversion_dlg();

#endif /* __GABEDIT_CONVUTILS_H__ */

