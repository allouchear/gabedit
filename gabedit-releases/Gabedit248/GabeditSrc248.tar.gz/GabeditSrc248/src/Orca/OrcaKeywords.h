#ifndef __GABEDIT_ORCAKEYWORDS_H__
#define __GABEDIT_ORCAKEYWORDS_H__

gboolean orcaSemiEmperical();
void putOrcaKeywordsInfoInTextEditor();
void createOrcaKeywordsFrame(GtkWidget *win, GtkWidget *box);
void setOrcaSCFMethod(gboolean okRHF);

#endif /* __GABEDIT_ORCAKEYWORDS_H__ */
