#ifndef __GABEDIT_NWCHEMGUESS_H__
#define __GABEDIT_NWCHEMGUESS_H__

void initNWChemGuessFrame();
void setSensitiveNWChemGuessMixed(gboolean sensitive);
void putNWChemGuessInfoInTextEditor();
void createNWChemGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_NWCHEMGUESS_H__ */
