
#ifndef __GABEDIT_MPQCMOLE_H__
#define __GABEDIT_MPQCMOLE_H__

void initMPQCMole();
void freeMPQCMole();
void createMPQCMole(GtkWidget *box);
void createMPQCGuess(GtkWidget *box);
void putMPQCMoleInfoInTextEditor();

#endif /* __GABEDIT_MPQCMOLE_H__ */

