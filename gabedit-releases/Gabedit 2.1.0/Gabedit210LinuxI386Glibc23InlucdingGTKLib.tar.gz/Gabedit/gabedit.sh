#! /bin/sh
#export  GABEDITDIR=$HOME/Gabedit
export  DEFDIR=`pwd`
export  GABEDITDIR=`dirname $0`
cd $GABEDITDIR
export  LD_LIBRARY_PATH=.:$LD_LIBRARY_PATH
export  PANGO_RC_FILE=./pangorc
export  GDK_PIXBUF_MODULEDIR=./gdk/loaders
export  GDK_PIXBUF_MODULE_FILE=./gdk/gdk-pixbuf.loaders
if [ -z "$1" ] 
then
./.gabedit.exe 
else
./.gabedit.exe $DEFDIR/$1
fi
