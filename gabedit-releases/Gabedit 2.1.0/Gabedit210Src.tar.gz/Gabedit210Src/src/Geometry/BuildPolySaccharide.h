
#ifndef __GABEDIT_BUILDPOLYSACCHARIDE_H__
#define __GABEDIT_BUILDPOLYSACCHARIDE_H__

void build_polysaccharide_dlg();

#endif /* __GABEDIT_BUILDPOLYSACCHARIDE_H__ */

