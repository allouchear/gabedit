#ifndef __GABEDIT_QCHEMGUESS_H__
#define __GABEDIT_QCHEMGUESS_H__

void initQChemGuessFrame();
void setSensitiveQChemGuessMixed(gboolean sensitive);
void putQChemGuessInfoInTextEditor();
void createQChemGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_QCHEMGUESS_H__ */
