
#ifndef __GABEDIT_MPQCOPTIMIZATION_H__
#define __GABEDIT_MPQCOPTIMIZATION_H__

void initMPQCOptimization();
void freeMPQCOptimization();
void createMPQCOptimization(GtkWidget *box);
void putMPQCOptimizationInfoInTextEditor();

#endif /* __GABEDIT_MPQCOPTIMIZATION_H__ */

