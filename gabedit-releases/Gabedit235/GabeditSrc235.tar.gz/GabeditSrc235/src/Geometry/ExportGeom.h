
#ifndef __GABEDIT_EXPORTGEOM_H__
#define __GABEDIT_EXPORTGEOM_H__

void export_geometry_dlg(gchar* type);

#endif /* __GABEDIT_EXPORTGEOM_H__ */

