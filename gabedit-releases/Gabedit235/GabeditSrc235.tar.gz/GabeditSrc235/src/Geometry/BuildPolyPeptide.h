
#ifndef __GABEDIT_BUILDPOLYPEPTIDE_H__
#define __GABEDIT_BUILDPOLYPEPTIDE_H__

void build_polypeptide_dlg();

#endif /* __GABEDIT_BUILDPOLYPEPTIDE_H__ */

