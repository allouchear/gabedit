
#ifndef __GABEDIT_POVRAY_H__
#define __GABEDIT_POVRAY_H__

void exportPOVGeomDlg(GtkWidget *parentWindow);

#endif /* __GABEDIT_POVRAY_H__ */

