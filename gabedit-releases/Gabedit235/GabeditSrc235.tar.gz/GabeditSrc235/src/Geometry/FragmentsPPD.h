
#ifndef __GABEDIT_FRAGMENTSPPD_H__
#define __GABEDIT_FRAGMENTSPPD_H__

Fragment GetFragmentPPD(gchar* Name);

#endif /* __GABEDIT_FRAGMENTSPPD_H__ */

