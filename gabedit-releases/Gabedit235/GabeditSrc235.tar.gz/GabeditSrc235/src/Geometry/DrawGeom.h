#ifndef __GABEDIT_DRAWGEOM_H__
#define __GABEDIT_DRAWGEOM_H__

#ifdef DRAWGEOMGL
#include "DrawGeomGL.h"
#else
#include "DrawGeomCairo.h"
#endif

#endif /* __GABEDIT_DRAWGEOM_H__ */
