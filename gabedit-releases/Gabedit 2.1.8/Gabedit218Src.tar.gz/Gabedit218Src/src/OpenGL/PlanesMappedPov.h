
#ifndef __GABEDIT_PLANESMAPPEDPOV_H__
#define __GABEDIT_PLANESMAPPEDPOV_H__

gint addPlaneMappedPovRay(Grid* plansgrid, gint i0,gint i1,gint numPlane, gfloat gap);
void deletePlanesMappedPovRayFile();

#endif /* __GABEDIT_PLANESMAPPEDPOV_H__ */

