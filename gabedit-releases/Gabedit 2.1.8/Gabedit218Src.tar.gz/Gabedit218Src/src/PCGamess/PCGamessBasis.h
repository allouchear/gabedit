#ifndef __GABEDIT_PCGAMESSBASIS_H__
#define __GABEDIT_PCGAMESSBASIS_H__

void initPCGamessBasisFrame();
void setSensitivePCGamessBasisFrame(gboolean sensitive);
void putPCGamessBasisInfoInTextEditor();
void createPCGamessBasisFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_PCGAMESSBASIS_H__ */
