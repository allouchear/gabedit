#ifndef __GABEDIT_MOPACCONTROL_H__
#define __GABEDIT_MOPACCONTROL_H__

gboolean mopacSemiEmperical();
void putMopacRemInfoInTextEditor();
void createMopacRemFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_MOPACCONTROL_H__ */
