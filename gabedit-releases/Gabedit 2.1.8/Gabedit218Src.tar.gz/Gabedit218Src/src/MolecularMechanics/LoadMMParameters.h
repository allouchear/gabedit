
#ifndef __GABEDIT_LOADMMPARAMETERS_H__
#define __GABEDIT_LOADMMPARAMETERS_H__

gboolean readAmberParameters(AmberParameters* amberParameters,gchar* filename);

#endif /* __GABEDIT_LOADMMPARAMETERS_H__ */

