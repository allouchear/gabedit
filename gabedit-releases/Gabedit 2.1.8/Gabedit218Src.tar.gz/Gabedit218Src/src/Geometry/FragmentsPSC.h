
#ifndef __GABEDIT_FRAGMENTSPSC_H__
#define __GABEDIT_FRAGMENTSPSC_H__

Fragment GetFragmentPSC(gchar* Name,gboolean alpha);

#endif /* __GABEDIT_FRAGMENTSPSC_H__ */

