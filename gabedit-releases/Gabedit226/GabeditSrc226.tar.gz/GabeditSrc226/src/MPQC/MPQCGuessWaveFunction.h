
#ifndef __GABEDIT_MPQCGUESSWAVEFUNCTION_H__
#define __GABEDIT_MPQCGUESSWAVEFUNCTION_H__

void initMPQCGuessWaveFunction();
void freeMPQCGuessWaveFunction();
void createMPQCGuess(GtkWidget *box);
void putMPQCGuessWaveFunctionInfoInTextEditor();

#endif /* __GABEDIT_MPQCGUESSWAVEFUNCTION_H__ */

