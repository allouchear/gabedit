
#ifndef __GABEDIT_SETPDBTEMPLATE_H__
#define __GABEDIT_SETPDBTEMPLATE_H__

void setPDBTemplateDlg();

#endif /* __GABEDIT_SETPDBTEMPLATE_H__ */

