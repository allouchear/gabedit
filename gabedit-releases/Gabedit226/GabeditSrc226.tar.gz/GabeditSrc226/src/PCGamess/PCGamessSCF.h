#ifndef __GABEDIT_PCGAMESSSCF_H__
#define __GABEDIT_PCGAMESSSCF_H__

void initPCGamessSCFFrame();
void setSensitivePCGamessSCFFrame(gboolean sensitive);
void putPCGamessSCFInfoInTextEditor();
void createPCGamessSCFFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_PCGAMESSSCF_H__ */
