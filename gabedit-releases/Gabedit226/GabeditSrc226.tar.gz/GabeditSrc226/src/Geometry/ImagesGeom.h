
#ifndef __GABEDIT_IMAGESGEOM_H__
#define __GABEDIT_IMAGESGEOM_H__

void save_geometry_jpeg_file(GabeditFileChooser *SelecFile, gint response_id);
void save_geometry_ppm_file(GabeditFileChooser *SelecFile, gint response_id);
void save_geometry_bmp_file(GabeditFileChooser *SelecFile, gint response_id);
void save_geometry_ps_file(GabeditFileChooser *SelecFile, gint response_id);
void save_geometry_png_file(GabeditFileChooser *SelecFile, gint response_id);

#endif /* __GABEDIT_IMAGESGEOM_H__ */
