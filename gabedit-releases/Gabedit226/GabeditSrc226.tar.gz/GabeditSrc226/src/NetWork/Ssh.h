
#ifndef __GABEDIT_SSH_H__
#define __GABEDIT_SSH_H__

void ssh (char *fout,char *ferr,const char* cmd, 
		  const char *hostname,const char* username,
		  const char* password 
		  );

#endif /* __GABEDIT_SSH_H__ */

