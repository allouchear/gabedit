
#ifndef __GABEDIT_SURFACESPOV_H__
#define __GABEDIT_SURFACESPOV_H__

gint createLastSurfacePovRay();
void addLastSurface();
void deleteSurfacesPovRayFile();

#endif /* __GABEDIT_SURFACESPOV_H__ */

