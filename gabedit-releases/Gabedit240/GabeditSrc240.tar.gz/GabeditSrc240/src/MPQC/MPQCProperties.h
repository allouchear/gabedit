
#ifndef __GABEDIT_MPQCPROPERTIES_H__
#define __GABEDIT_MPQCPROPERTIES_H__

void createMPQCProperties(GtkWidget *box);
void putMPQCPropertiesInfoInTextEditor();

#endif /* __GABEDIT_MPQCPROPERTIES_H__ */

