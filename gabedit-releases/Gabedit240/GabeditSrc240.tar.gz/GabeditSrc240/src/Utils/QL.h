gint eigen(gdouble *M, gint n, gdouble *d, gdouble** v);
