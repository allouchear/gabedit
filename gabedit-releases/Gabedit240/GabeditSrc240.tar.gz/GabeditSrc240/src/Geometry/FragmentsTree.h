
#ifndef __GABEDIT_FRAGMENTSTREE_H__
#define __GABEDIT_FRAGMENTSTREE_H__

GtkWidget* addFragmentsTreeView(GtkWidget *box);
void rafreshTreeView(GtkWidget *treeView);

#endif /* __GABEDIT_FRAGMENTSTREE_H__ */

