#ifndef __GABEDIT_DEMONGUESS_H__
#define __GABEDIT_DEMONGUESS_H__

void initDeMonGuessFrame();
void setSensitiveDeMonGuessMixed(gboolean sensitive);
void putDeMonGuessInfoInTextEditor();
void createDeMonGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_DEMONGUESS_H__ */
