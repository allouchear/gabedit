#ifndef __GABEDIT_FIREFLYBASIS_H__
#define __GABEDIT_FIREFLYBASIS_H__

void initFireFlyBasisFrame();
void setSensitiveFireFlyBasisFrame(gboolean sensitive);
void putFireFlyBasisInfoInTextEditor();
void createFireFlyBasisFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_FIREFLYBASIS_H__ */
