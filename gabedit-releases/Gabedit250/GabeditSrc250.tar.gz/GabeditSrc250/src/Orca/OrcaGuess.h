#ifndef __GABEDIT_ORCAGUESS_H__
#define __GABEDIT_ORCAGUESS_H__

void initOrcaGuessFrame();
void setSensitiveOrcaGuessMixed(gboolean sensitive);
void putOrcaGuessInfoInTextEditor();
void createOrcaGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_ORCAGUESS_H__ */
