#ifndef __GABEDIT_PSICODEGUESS_H__
#define __GABEDIT_PSICODEGUESS_H__

void initPsicodeGuessFrame();
void setSensitivePsicodeGuessMixed(gboolean sensitive);
void putPsicodeGuessInfoInTextEditor();
void createPsicodeGuessFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_PSICODEGUESS_H__ */
