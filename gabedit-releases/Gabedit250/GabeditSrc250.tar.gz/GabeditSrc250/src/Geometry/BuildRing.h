
#ifndef __GABEDIT_BUILDRING_H__
#define __GABEDIT_BUILDRING_H__

void build_ring_molecule_dlg();

#endif /* __GABEDIT_BUILDRING_H__ */

