#ifndef __GABEDIT_DEMONKEYWORDS_H__
#define __GABEDIT_DEMONKEYWORDS_H__

gboolean demonSemiEmperical();
void putDeMonKeywordsInfoInTextEditor();
void createDeMonKeywordsFrame(GtkWidget *win, GtkWidget *box);
void setDeMonSCFMethod(gboolean okRHF);

#endif /* __GABEDIT_DEMONKEYWORDS_H__ */
