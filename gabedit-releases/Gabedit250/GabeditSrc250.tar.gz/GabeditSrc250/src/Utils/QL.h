gint eigen(gdouble *M, gint n, gdouble *d, gdouble** v);
gint eigenQL(gint n, gdouble **M, gdouble *d, gdouble** v);
