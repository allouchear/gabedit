
#ifndef __GABEDIT_SETMMPARAMETERS_H__
#define __GABEDIT_SETMMPARAMETERS_H__

void setMMParamatersDlg();

#endif /* __GABEDIT_SETMMPARAMETERS_H__ */

