#ifndef __GABEDIT_GAMESSBASIS_H__
#define __GABEDIT_GAMESSBASIS_H__

void initGamessBasisFrame();
void setSensitiveGamessBasisFrame(gboolean sensitive);
void putGamessBasisInfoInTextEditor();
void createGamessBasisFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_GAMESSBASIS_H__ */
