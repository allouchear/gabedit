
#ifndef __GABEDIT_BABEL_H__
#define __GABEDIT_BABEL_H__

void create_babel_dialogue();
GtkWidget* create_babel_read_save_dialogue(gboolean read);

#endif /* __GABEDIT_BABEL_H__ */

