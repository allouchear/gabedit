
#ifndef __GABEDIT_FRAGMENTSCRYSTAL_H__
#define __GABEDIT_FRAGMENTSCRYSTAL_H__

Fragment GetFragmentPrototypeCrystals(gchar* Name);
Fragment GetFragmentElementCrystals(gchar* Name);
Fragment GetFragmentCrystal(gchar* Name);

#endif /* __GABEDIT_FRAGMENTSCRYSTAL_H__ */

