AtomML.o: AtomML.c ../../Config.h ../Common/Global.h \
 ../Common/../Files/GabeditFileChooser.h \
 ../Common/../Common/GabeditType.h ../Utils/Constants.h \
 ../Utils/AtomsProp.h ../Geometry/Fragments.h ../Geometry/DrawGeom.h \
 ../Geometry/DrawGeomCairo.h ../Geometry/Fragments.h AtomML.h
MoleculeML.o: MoleculeML.c ../../Config.h ../Common/Global.h \
 ../Common/../Files/GabeditFileChooser.h \
 ../Common/../Common/GabeditType.h ../Utils/AtomsProp.h \
 ../Geometry/Fragments.h ../Geometry/DrawGeom.h \
 ../Geometry/DrawGeomCairo.h ../Geometry/Fragments.h \
 ../Geometry/Measure.h ../Geometry/GeomGlobal.h \
 ../Geometry/../Common/GabeditType.h ../Geometry/GeomXYZ.h \
 ../Utils/Constants.h ../Utils/Utils.h AtomML.h MoleculeML.h
MachineLearningDlg.o: MachineLearningDlg.c ../../Config.h \
 ../Common/Global.h ../Common/../Files/GabeditFileChooser.h \
 ../Common/../Common/GabeditType.h ../Utils/UtilsInterface.h \
 ../Utils/Constants.h ../Geometry/Fragments.h ../Geometry/DrawGeom.h \
 ../Geometry/DrawGeomCairo.h ../Geometry/Fragments.h \
 ../Geometry/Measure.h ../Geometry/ResultsAnalise.h \
 ../Geometry/GeomGlobal.h ../Geometry/../Common/GabeditType.h \
 ../Geometry/GeomXYZ.h ../Utils/Utils.h ../Utils/AtomsProp.h \
 ../Files/FolderChooser.h ../Files/GabeditFolderChooser.h \
 MachineLearningDlg.h MoleculeML.h AtomML.h
