
#ifndef __GABEDIT_BUILDLINEAR_H__
#define __GABEDIT_BUILDLINEAR_H__

void build_linear_molecule_dlg();

#endif /* __GABEDIT_BUILDLINEAR_H__ */

