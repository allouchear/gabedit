
#ifndef __GABEDIT_CALCULTYPESAMBER_H__
#define __GABEDIT_CALCULTYPESAMBER_H__

void calculTypesAmber(GeomDef* geom, gint nAtoms);
void calculTypesAmberForAFragment(Fragment* F);

#endif /* __GABEDIT_CALCULTYPESAMBER_H__ */

