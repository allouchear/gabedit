
#ifndef __GABEDIT_CONTOURSPOV_H__
#define __GABEDIT_CONTOURSPOV_H__

gint addContoursPovRay(Grid* plansgrid,gint Ncontours,gdouble* values,gint i0,gint i1,gint numplan,gdouble gap);
void deleteContoursPovRayFile();

#endif /* __GABEDIT_CONTOURSPOV_H__ */

