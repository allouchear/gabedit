
#ifndef __GABEDIT_ECDSPECTRUM_H__
#define __GABEDIT_ECDSPECTRUM_H__

void createECDSpectrum(GtkWidget *parentWindow, GabEditTypeFile typeOfFile);

#endif /* __GABEDIT_ECDSPECTRUM_H__ */
