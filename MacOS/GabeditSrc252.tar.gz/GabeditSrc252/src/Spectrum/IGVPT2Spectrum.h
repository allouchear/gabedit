
#ifndef __GABEDIT_IGVPT2SPECTRUM_H__
#define __GABEDIT_IGVPT2SPECTRUM_H__


GtkWidget* AnharmonicResultTxt(gchar *message,gchar *title);
void create_igvpt2_file_dlg(gboolean run);

#endif /* __GABEDIT_IGVPT2SPECTRUM_H__ */
