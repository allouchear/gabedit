
#ifndef __GABEDIT_VASPSPECTRA_H__
#define __GABEDIT_VASPSPECTRA_H__

void read_vasp_xml_file_dlg();

#endif /* __GABEDIT_VASPSPECTRA_H__ */
