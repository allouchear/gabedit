#ifndef __GABEDIT_GAMESSSCF_H__
#define __GABEDIT_GAMESSSCF_H__

void initGamessSCFFrame();
void setSensitiveGamessSCFFrame(gboolean sensitive);
void putGamessSCFInfoInTextEditor();
void createGamessSCFFrame(GtkWidget *win, GtkWidget *box);

#endif /* __GABEDIT_GAMESSSCF_H__ */
