
#ifndef __GABEDIT_LOADPERSONALFRAGMENTS_H__
#define __GABEDIT_LOADPERSONALFRAGMENTS_H__

PersonalFragments* loadAllPersonalFragments(gchar* filename);

#endif /* __GABEDIT_LOADPERSONALFRAGMENTS_H__ */

