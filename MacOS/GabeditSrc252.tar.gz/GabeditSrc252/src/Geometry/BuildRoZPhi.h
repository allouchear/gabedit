
#ifndef __GABEDIT_BUILDROZPHI_H__
#define __GABEDIT_BUILDROZPHI_H__

void build_rozphi_molecule_dlg();

#endif /* __GABEDIT_BUILDROZPHI_H__ */


