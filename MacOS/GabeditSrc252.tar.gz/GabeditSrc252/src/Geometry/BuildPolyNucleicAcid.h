
#ifndef __GABEDIT_BUILDPOLYNUCLEICACID_H__
#define __GABEDIT_BUILDPOLYNUCLEICACID_H__

void build_polynucleicacid_dlg();

#endif /* __GABEDIT_BUILDPOLYNUCLEICACID_H__ */

