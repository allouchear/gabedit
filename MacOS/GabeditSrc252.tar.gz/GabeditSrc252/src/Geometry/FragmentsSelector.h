
#ifndef __GABEDIT_FRAGMENTSSELECTOR_H__
#define __GABEDIT_FRAGMENTSSELECTOR_H__

void create_window_fragments_selector(gchar* nodeNameToExpand, gchar* fragmentToSelect);
void rafresh_fragments_selector();
void hide_fragments_selector();
void show_fragments_selector();

#endif /* __GABEDIT_FRAGMENTSSELECTOR_H__ */

