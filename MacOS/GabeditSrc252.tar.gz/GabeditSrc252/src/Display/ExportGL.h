
#ifndef __GABEDIT_EXPORTGL_H__
#define __GABEDIT_EXPORTGL_H__

void export_scene(GtkWidget* Win,gchar* type);

#endif /* __GABEDIT_EXPORTGL_H__ */

