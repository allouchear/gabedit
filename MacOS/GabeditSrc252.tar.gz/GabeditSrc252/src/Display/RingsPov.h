
#ifndef __GABEDIT_RINGSPOV_H__
#define __GABEDIT_RINGSPOV_H__

void AddRingsPovRay(GList** rings, gint nRings, gint* ringsSize, V4d colors[]);
void deleteRingsPovRayFile();

#endif /* __GABEDIT_RINGSPOV_H__ */

