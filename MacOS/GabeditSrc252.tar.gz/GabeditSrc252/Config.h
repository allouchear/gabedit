/* Config header file */
#ifndef ENABLE_DEPRECATED
#define GTK_DISABLE_DEPRECATED
#define GDK_DISABLE_DEPRECATED
#define PANGO_DISABLE_DEPRECATED
#endif
#define GETTEXT_PACKAGE "gabedit"
