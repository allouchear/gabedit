/* gdkglext-config.h
 *
 * This is a generated file.  Please modify `configure.ac'
 */

#ifndef GDKGLEXT_CONFIG_H
#define GDKGLEXT_CONFIG_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#define GDKGLEXT_WINDOWING_X11

#define GDKGLEXT_NEED_GLXFBCONFIGSGIX_TYPEDEF

#define GDKGLEXT_NEED_GLXFBCONFIGIDSGIX_TYPEDEF

#define GDKGLEXT_NEED_GLXPBUFFERSGIX_TYPEDEF

#define GDKGLEXT_NEED_GLXVIDEOSOURCESGIX_TYPEDEF

#define GDKGLEXT_NEED_GLXEXTFUNCPTR_TYPEDEF

#define GDKGLEXT_NEED_GLHALFNV_TYPEDEF

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* GDKGLEXT_CONFIG_H */
