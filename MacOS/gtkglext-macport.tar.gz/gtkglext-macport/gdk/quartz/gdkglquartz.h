
#ifndef __GDK_GL_X_H__
#define __GDK_GL_X_H__

#include <gdk/gdkquartz.h>

#include <OpenGL/gl.h>

#endif